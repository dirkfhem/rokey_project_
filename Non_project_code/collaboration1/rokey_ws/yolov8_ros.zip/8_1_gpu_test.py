import torch

print(torch.version.cuda)

print(torch.cuda.is_available())

