// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_pkg_srv_test:srv/CustomService.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_PKG_SRV_TEST__SRV__CUSTOM_SERVICE_H_
#define CUSTOM_PKG_SRV_TEST__SRV__CUSTOM_SERVICE_H_

#include "custom_pkg_srv_test/srv/detail/custom_service__struct.h"
#include "custom_pkg_srv_test/srv/detail/custom_service__functions.h"
#include "custom_pkg_srv_test/srv/detail/custom_service__type_support.h"

#endif  // CUSTOM_PKG_SRV_TEST__SRV__CUSTOM_SERVICE_H_
