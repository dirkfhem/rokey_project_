// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_PKG_SRV_TEST__SRV__CUSTOM_SERVICE_HPP_
#define CUSTOM_PKG_SRV_TEST__SRV__CUSTOM_SERVICE_HPP_

#include "custom_pkg_srv_test/srv/detail/custom_service__struct.hpp"
#include "custom_pkg_srv_test/srv/detail/custom_service__builder.hpp"
#include "custom_pkg_srv_test/srv/detail/custom_service__traits.hpp"
#include "custom_pkg_srv_test/srv/detail/custom_service__type_support.hpp"

#endif  // CUSTOM_PKG_SRV_TEST__SRV__CUSTOM_SERVICE_HPP_
