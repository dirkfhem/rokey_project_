// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from custom_pkg_srv_test:srv/CustomService.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_PKG_SRV_TEST__SRV__DETAIL__CUSTOM_SERVICE__STRUCT_H_
#define CUSTOM_PKG_SRV_TEST__SRV__DETAIL__CUSTOM_SERVICE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'brand'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/CustomService in the package custom_pkg_srv_test.
typedef struct custom_pkg_srv_test__srv__CustomService_Request
{
  rosidl_runtime_c__String brand;
  int32_t count;
} custom_pkg_srv_test__srv__CustomService_Request;

// Struct for a sequence of custom_pkg_srv_test__srv__CustomService_Request.
typedef struct custom_pkg_srv_test__srv__CustomService_Request__Sequence
{
  custom_pkg_srv_test__srv__CustomService_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_pkg_srv_test__srv__CustomService_Request__Sequence;


// Constants defined in the message

/// Struct defined in srv/CustomService in the package custom_pkg_srv_test.
typedef struct custom_pkg_srv_test__srv__CustomService_Response
{
  bool success;
} custom_pkg_srv_test__srv__CustomService_Response;

// Struct for a sequence of custom_pkg_srv_test__srv__CustomService_Response.
typedef struct custom_pkg_srv_test__srv__CustomService_Response__Sequence
{
  custom_pkg_srv_test__srv__CustomService_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_pkg_srv_test__srv__CustomService_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CUSTOM_PKG_SRV_TEST__SRV__DETAIL__CUSTOM_SERVICE__STRUCT_H_
